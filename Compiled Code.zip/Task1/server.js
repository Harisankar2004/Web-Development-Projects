// server.js
const express = require("express");
const path = require("path");
const bodyParser = require("body-parser");
const cors = require("cors");
const fs = require("fs");

const app = express();
const PORT = 3000;

// Middleware
app.use(cors());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

// Serve static files from current folder
app.use(express.static(__dirname));

// In-memory storage
let submissions = [];

//  Root route: serve the form
app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "project.html")); // make sure this file exists!
});

// Handle form submission
app.post("/submit", (req, res) => {
  const data = req.body;
  data.timestamp = new Date().toISOString();
  submissions.push(data);

  fs.writeFileSync("submissions.json", JSON.stringify(submissions, null, 2));

  console.log("New form submission:", data);

  res.status(200).json({
    message: "Form submitted successfully!",
    data,
  });
});

//  View all submissions
app.get("/submissions", (req, res) => {
  res.json(submissions);
});

//  Clear all submissions
app.delete("/submissions", (req, res) => {
  submissions = [];
  fs.writeFileSync("submissions.json", "[]");
  res.json({ message: "All submissions cleared." });
});

// Start server
app.listen(PORT, () => {
  console.log(`🚀 Server running at http://localhost:${PORT}`);
});
